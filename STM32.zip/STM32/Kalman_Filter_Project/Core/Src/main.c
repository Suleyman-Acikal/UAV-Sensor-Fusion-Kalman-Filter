/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : STM32F0 MPU6050 + QMC5883P + BMP280 to MATLAB Real-Time
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "bmp280.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* QMC5883P I2C Address */
#define QMC5883P_ADDR (0x2C << 1)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_tx;

/* USER CODE BEGIN PV */
BMP280_HandleTypedef bmp280;
bmp280_params_t bmp280_params;

float bmp_temp;
float bmp_press;
float bmp_hum;

/* MPU6050 */
uint8_t mpu_id;
float ax, ay, az;
float gx, gy, gz;

/* QMC5883P */
float mx, my, mz;

/* UART */
char uart_buf[128];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C2_Init(void);
/* USER CODE BEGIN PFP */
void MPU6050_Init(void);
void MPU6050_Read_All(void);
void QMC5883P_Init(void);
void QMC5883P_Read(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  MX_I2C2_Init();

  /* USER CODE BEGIN 2 */
  MPU6050_Init();
  QMC5883P_Init();

  bmp280.i2c = &hi2c2;
  bmp280.addr = BMP280_I2C_ADDRESS_0;

  bmp280_init_default_params(&bmp280_params);

  if (!bmp280_init(&bmp280, &bmp280_params))
  {
      Error_Handler();
  }
  HAL_Delay(1000);

  HAL_UART_Transmit(&huart1, (uint8_t*)uart_buf, strlen(uart_buf), 1000);
  HAL_Delay(1000);
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      MPU6050_Read_All();
      QMC5883P_Read();
      bmp280_read_float(&bmp280, &bmp_temp, &bmp_press, NULL);

      HAL_Delay(500);

      /* CSV Order: ax, ay, az, gx, gy, gz, mx, my, mz, press */
      sprintf(uart_buf,
              "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\r\n",
              ax, ay, az,
              gx, gy, gz,
              mx, my, mz,
              bmp_press);

      HAL_UART_Transmit(&huart1, (uint8_t*)uart_buf, strlen(uart_buf), 1000);
      HAL_Delay(100);

    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  */
static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0010020A;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  */
static void MX_I2C2_Init(void)
{
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x2010091A;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */

/* MPU6050 IMU */
void MPU6050_Init(void)
{
    uint8_t check = 0;
    uint8_t data;

    HAL_I2C_Mem_Read(&hi2c1, (0x68 << 1), 0x75, 1, &check, 1, 1000);
    mpu_id = check;

    if (check == 0x68 || check == 0x72)
    {
        data = 0x01;
        HAL_I2C_Mem_Write(&hi2c1, (0x68 << 1), 0x6B, 1, &data, 1, 1000);
        HAL_Delay(50);

        data = 0x00;
        HAL_I2C_Mem_Write(&hi2c1, (0x68 << 1), 0x1C, 1, &data, 1, 1000);

        data = 0x00;
        HAL_I2C_Mem_Write(&hi2c1, (0x68 << 1), 0x1B, 1, &data, 1, 1000);
    }
}

void MPU6050_Read_All(void)
{
    uint8_t Rec_Data[14] = {0};
    int16_t accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z;

    if(HAL_I2C_Mem_Read(&hi2c1, (0x68 << 1), 0x3B, 1, Rec_Data, 14, 100) == HAL_OK)
    {
        accel_x = (int16_t)(Rec_Data[0] << 8 | Rec_Data[1]);
        accel_y = (int16_t)(Rec_Data[2] << 8 | Rec_Data[3]);
        accel_z = (int16_t)(Rec_Data[4] << 8 | Rec_Data[5]);

        gyro_x = (int16_t)(Rec_Data[8] << 8 | Rec_Data[9]);
        gyro_y = (int16_t)(Rec_Data[10] << 8 | Rec_Data[11]);
        gyro_z = (int16_t)(Rec_Data[12] << 8 | Rec_Data[13]);

        ax = accel_x / 16384.0f;
        ay = accel_y / 16384.0f;
        az = accel_z / 16384.0f;

        gx = gyro_x / 131.0f;
        gy = gyro_y / 131.0f;
        gz = gyro_z / 131.0f;
    }
}

/* QMC5883P Magnetometer */
void QMC5883P_Init(void)
{
    uint8_t data;

    data = 0x06;
    HAL_I2C_Mem_Write(&hi2c2, QMC5883P_ADDR, 0x29, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
    HAL_Delay(10);

    data = 0x08;
    HAL_I2C_Mem_Write(&hi2c2, QMC5883P_ADDR, 0x0B, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
    HAL_Delay(10);

    data = 0xCD;
    HAL_I2C_Mem_Write(&hi2c2, QMC5883P_ADDR, 0x0A, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
    HAL_Delay(10);
}

void QMC5883P_Read(void)
{
    uint8_t statusReg = 0;
    uint8_t Rec_Data[6] = {0};
    int16_t raw_x, raw_y, raw_z;

    HAL_I2C_Mem_Read(&hi2c2, QMC5883P_ADDR, 0x09, I2C_MEMADD_SIZE_8BIT, &statusReg, 1, 100);

    if ((statusReg & 0x01) == 0x01)
    {
        if (HAL_I2C_Mem_Read(&hi2c2, QMC5883P_ADDR, 0x01, I2C_MEMADD_SIZE_8BIT, Rec_Data, 6, 100) == HAL_OK)
        {
            raw_x = (int16_t)((Rec_Data[1] << 8) | Rec_Data[0]);
            raw_y = (int16_t)((Rec_Data[3] << 8) | Rec_Data[2]);
            raw_z = (int16_t)((Rec_Data[5] << 8) | Rec_Data[4]);

            mx = (float)raw_x;
            my = (float)raw_y;
            mz = (float)raw_z;
        }
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
